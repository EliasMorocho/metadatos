/*const OpenAI = require("openai");

const openai = new OpenAI();
*/
async function openaiUseCase(content) {
    /*try {
        const completion = await openai.chat.completions.create({
            messages: [{ role: "system", content: content }],
            model: "gpt-3.5-turbo",
        });

        console.log(completion);
    } catch (error) {
        console.error("Error:", error);
    }*/
}

module.exports = { openaiUseCase };
